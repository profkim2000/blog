// 팝업 스크립트(popup.js)에서 보낸 메시지를 수신 대기
chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {
    // 팝업에서 보낸 action이 'calculate_sum'일 경우에만 실행
    if (request.action === "check_dup") 
    {
      const threshold = request.threshold;
      console.log(`threshold = ${threshold}`);
      check_dup(threshold);
      // 처리 완료되었음을 팝업에 알림
      sendResponse({status: "success", message: "처리 완료 결과 표시"});
      return true; // 비동기 응답을 위해 필요
    }
  }
);

function check_dup(threshold) 
{
  const qjsons = document.getElementsByName('qjson');

  //console.log("qjsons = " , qjasons);
  if (!qjsons || qjsons.length <= 0) 
  {
    alert("qjson 엘리먼트가 없습니다.");
    return;
  }

  // json 값들을 가져온다.

  const questions = [];   // 전체 문제를 담는 배열. 기수별로 문제를 담는다.

  for (const element of qjsons)
  {
    //console.log(element.value);

    const question = [];

    // 각 기수별 문제를 하나씩 json으로 만든다.
    json = JSON.parse(element.value);

    for (i=0; i<json.questions.length; i++)
    {
      question_item = json.questions[i];
      //console.log(question_item);
      question.push(question_item); // 하나의 기수에 포함된 모든 문제를 담는다.
    }

    questions.push(question);    
  }
  
  // 각 기수별 문제를 하나씩 가져온 확인
  // for (i = 0; i < questions.length; i++)
  // {
  //   question_gisu = questions[i];
  //   console.log("question_gisu: ", question_gisu);
  // }

  const dup_check_result = [];

  // 각 기수별 문제를 중복 체크한다.
  for (i = 0; i < questions.length; i++)    // 전체 기수 루프
  {
    questions_gisu1 = questions[i];

    for (j = i+1; j < questions.length; j++)  // i 루프가 가리키는 다음 기수부터 비교한다.
    {
      questions_gisu2 = questions[j];

      for (k = 0; k < questions_gisu1.length; k++) // 기수1의 모든 문제 
      {
        question1 = questions_gisu1[k];
        question1_t = question1.q + ' ' + question1.a1 + ' ' + question1.a2 + ' ' + question1.a3 + ' ' + question1.a4;

        for (m = 0; m < questions_gisu2.length; m++) // 기수2의 모든 문제
        {
          question2 = questions_gisu2[m];
          question2_t = question2.q + ' ' + question2.a1 + ' ' + question2.a2 + ' ' + question2.a3 + ' ' + question2.a4;

          const sim = getCosineSimilarityForSentences(question1_t, question2_t).toFixed(2);
          const simpro = sim * 100;
          
          //console.log(`유사도 : \n- 기수 1 : ${question1.year}년 ${question1.gisu}기 ${question1.no}. ${question1_t}\n- 기수 2: ${question2.year}년, ${question2.gisu}기 ${question2.no}. ${question2_t}\n-유사도: ${simpro}%`);          

          const question1_stype = question1.type == 1 ? "연수" : "수탁";
          const question2_stype = question2.type == 1 ? "연수" : "수탁";
          const result_item = {
            question1_year: question1.year,
            question1_type: question1.type,
            question1_gisu: question1.gisu,
            question1_no: question1.no,
            question1_q : `<h3>${question1.year}년 ${question1_stype} ${question1.gisu}기</h3>` + question1.no + '. ' + question1.q + '<br />①' + question1.a1 + '<br />②' + question1.a2 + '<br />③' + question1.a3 + '<br />④' + question1.a4,

            question2_year: question2.year,
            question2_type: question2.type,
            question2_gisu: question2.gisu,
            question2_no: question2.no,
            question2_stype: question2.type == 1 ? "연수" : "수탁",
            question2_q : `<h3>${question2.year}년 ${question2_stype} ${question2.gisu}기</h3>` + question2.no + '. ' + question2.q + '<br />①' + question2.a1 + '<br />②' + question2.a2 + '<br />③' + question2.a3 + '<br />④' + question2.a4 + '<br /><br />유사도: ' + simpro + '%',

            sim: sim  
          }

          //console.log('result_item: ', result_item);

          dup_check_result.push(result_item);
        }
      }
      
    }
    
  }

  console.log('dup_check_result = ', dup_check_result);


  // 5. 결과를 웹페이지 아래에 표시합니다.
  displayResult(dup_check_result, threshold);
}

// 결과를 웹페이지에 삽입하는 함수
function displayResult(dup_check_result, threshold) 
{
  // 기존에 표시된 결과 엘리먼트가 있다면 제거합니다.
  let resultDisplay = document.getElementById('extension-sum-result-display');
  if (resultDisplay) 
  {
    resultDisplay.remove();
  }

  let question1_display_ = document.getElementById('question1_display');
  if (question1_display_) 
  {
    question1_display_.remove();
  }

  let question2_display_ = document.getElementById('question2_display');
  if (question2_display_) 
  {
    question2_display_.remove();
  }
  
  // 새로운 결과 표시 엘리먼트 생성
  resultDisplay = document.createElement('div');
  resultDisplay.id = 'extension-sum-result-display';
  
  // 스타일 지정 (페이지 내용과 겹치지 않도록 고정 위치)
  resultDisplay.style.cssText = `
    position: fixed;
    bottom: 20px;
    left: 20px;
    right: 20px;
    width: 90%;    
    margin: 0 auto;
    height: 500px;
    background-color: #333;
    color: white;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    z-index: 99999;
    font-size: 16px;
    font-family: sans-serif;
    overflow: auto;
  `;


  // 문제 보여주기 
  const question1_display = document.createElement('div');
  question1_display.id = 'question1_display';
  
  // 스타일 지정 (페이지 내용과 겹치지 않도록 고정 위치)
  question1_display.style.cssText = `
    position: fixed;
    top: 20px;
    left: 150px;
    right: 20px;
    width: 40%;    
    height: 300px;
    background-color: #bbbbbb;
    color: black;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    z-index: 99999;
    font-size: 16px;
    font-family: sans-serif;
    overflow: auto;
    visibility: hidden;
  `;

  const question2_display = document.createElement('div');
  question2_display.id = 'question2_display';
  
  // 스타일 지정 (페이지 내용과 겹치지 않도록 고정 위치)
  question2_display.style.cssText = `
    position: fixed;
    top: 20px;
    right: 150px;
    width: 40%;        
    height: 300px;
    background-color: #bbbbbb;
    color: black;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    z-index: 99999;
    font-size: 16px;
    font-family: sans-serif;
    overflow: auto;
    visibility: hidden;
  `;
  
  
  let html = '<h4> 유사도 검사 결과</h4>';
  
  html += "<style>table {width:100%; border-collapse: collapse;} th, td {padding:10px;} </style>";
  html += "<table id='result_table' border=1><tr><th>년</th><th>구분</th><th>기수</th><th>문제번호</th><th>년</th><th>구분</th><th>기수</th><th>문제번호</th><th>유사도</th></tr>";
  for (var i=0; i < dup_check_result.length; i++)
  {
    const result_item = dup_check_result[i];
    const type1 = result_item.question1_type == 1 ? "연수" : "수탁";
    const type2 = result_item.question2_type == 1 ? "연수" : "수탁";
    const simpro = result_item.sim * 100;

    console.log(`threshold = ${threshold}, simpro = ${simpro}`);

    if (threshold <= simpro)
    {
      html += `<tr id='item_${i}' align='center' onclick="( () => {
                    question1_display.innerHTML = '${result_item.question1_q}'; 
                    question2_display.innerHTML = '${result_item.question2_q}'; 
                    question1_display.style.visibility='visible'; 
                    question2_display.style.visibility='visible';
                    
                    // 다른 것들의 색을 바꾼다.
                    const table = document.getElementById('result_table');
                    const tr_list = table.querySelectorAll('tr');
                    tr_list.forEach(function(row) {
                      row.style.backgroundColor = '#333';
                    });

                    // 현재 tr의 배경색을 바꾼다.
                    const current_tr = document.getElementById('item_${i}');
                    current_tr.style.backgroundColor = '#666';

                })()">`;
      html += `<td>${result_item.question1_year}</td>`;
      html += `<td>${type1}</td>`;
      html += `<td>${result_item.question1_gisu}</td>`;
      html += `<td>${result_item.question1_no}</td>`;

      html += `<td>${result_item.question2_year}</td>`;
      html += `<td>${type2}</td>`;
      html += `<td>${result_item.question2_gisu}</td>`;
      html += `<td>${result_item.question2_no}</td>`;

      html += `<td>${simpro}%</td>`;

      html += '</tr>';
    }
  }

  html += '</table>';

  
  
  resultDisplay.innerHTML = html;
  

  // body의 맨 끝에 결과를 추가합니다.
  document.body.appendChild(resultDisplay);
  document.body.appendChild(question1_display);
  document.body.appendChild(question2_display);
}


/**
 * 텍스트를 단어 배열로 토큰화하는 함수
 * 한국어의 경우, 띄어쓰기(공백) 기준으로 단순 분리합니다.
 * @param {string} text - 입력 텍스트
 * @returns {string[]} - 토큰(단어) 배열
 */
function tokenize(text) {
    // 텍스트를 소문자로 변환하고, 알파벳/숫자/한글이 아닌 문자를 공백으로 대체 후, 공백을 기준으로 분리
    return text
        .toLowerCase()
        .replace(/[^a-z0-9가-힣\s]/g, ' ') 
        .split(/\s+/) // 하나 이상의 공백으로 분리
        .filter(token => token.length > 0); // 빈 토큰 제거
}

/**
 * 두 문장의 코사인 유사도를 계산하는 함수
 * @param {string} textA - 첫 번째 문장
 * @param {string} textB - 두 번째 문장
 * @returns {number} - 0에서 1 사이의 코사인 유사도 값
 */
function getCosineSimilarityForSentences(textA, textB) {
    if (!textA || !textB) return 0;

    // 1. 토큰화
    const tokensA = tokenize(textA);
    const tokensB = tokenize(textB);

    // 2. 단어장 구축 (두 문장의 모든 고유 단어)
    const vocab = new Map();
    let index = 0;
    
    // T1과 T2의 모든 토큰을 단어장에 추가
    for (const token of [...tokensA, ...tokensB]) {
        if (!vocab.has(token)) {
            vocab.set(token, index++);
        }
    }

    const vocabSize = vocab.size;

    // 두 문장이 모두 토큰을 생성하지 못한 경우
    if (vocabSize === 0) {
        return (textA === textB) ? 1 : 0;
    }

    // 3. TF 벡터 생성
    const vectorA = new Array(vocabSize).fill(0);
    const vectorB = new Array(vocabSize).fill(0);

    for (const token of tokensA) {
        vectorA[vocab.get(token)] += 1;
    }

    for (const token of tokensB) {
        vectorB[vocab.get(token)] += 1;
    }

    // 4. 코사인 유사도 계산
    let dotProduct = 0;
    let magnitudeA = 0;
    let magnitudeB = 0;

    for (let i = 0; i < vocabSize; i++) {
        dotProduct += vectorA[i] * vectorB[i];
        magnitudeA += vectorA[i] * vectorA[i];
        magnitudeB += vectorB[i] * vectorB[i];
    }

    const denom = Math.sqrt(magnitudeA) * Math.sqrt(magnitudeB);

    if (denom === 0) {
        return 0; // 이전에 걸러졌겠지만 안전을 위해 추가
    }

    return dotProduct / denom;
}