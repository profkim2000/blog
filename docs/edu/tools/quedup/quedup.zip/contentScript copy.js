// 팝업 스크립트(popup.js)에서 보낸 메시지를 수신 대기
chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {
    // 팝업에서 보낸 action이 'calculate_sum'일 경우에만 실행
    if (request.action === "check_dup") {
      check_dup();
      // 처리 완료되었음을 팝업에 알림
      sendResponse({status: "success", message: "처리 완료 결과 표시"});
      return true; // 비동기 응답을 위해 필요
    }
  }
);

function check_dup() {
  // 1. name=a1과 name=a2인 <input type="text"> 엘리먼트를 찾습니다.
  const inputA1 = document.querySelector('input[name="a1"][type="text"]');
  const inputA2 = document.querySelector('input[name="a2"][type="text"]');

  if (!inputA1 || !inputA2) {
    alert("웹페이지에서 'a1' 또는 'a2' 입력 필드를 찾을 수 없습니다.");
    return;
  }

  // 2. 값(value)을 가져와서 숫자로 변환합니다.
  // Number() 함수를 사용하여 숫자가 아니면 NaN이 되도록 처리합니다.
  const val1 = Number(inputA1.value);
  const val2 = Number(inputA2.value);

  // 3. 값이 유효한 숫자인지 확인합니다.
  if (isNaN(val1) || isNaN(val2)) {
    alert("입력 필드에 유효한 숫자 값이 들어있지 않습니다. 현재 값: a1=" + inputA1.value + ", a2=" + inputA2.value);
    return;
  }

  // 4. 두 숫자를 더합니다.
  const sum = val1 + val2;

  // 5. 결과를 웹페이지 아래에 표시합니다.
  displayResult(sum, inputA1.value, inputA2.value);
}

// 결과를 웹페이지에 삽입하는 함수
function displayResult(sum, rawVal1, rawVal2) {
  // 기존에 표시된 결과 엘리먼트가 있다면 제거합니다.
  let resultDisplay = document.getElementById('extension-sum-result-display');
  if (resultDisplay) {
    resultDisplay.remove();
  }
  
  // 새로운 결과 표시 엘리먼트 생성
  resultDisplay = document.createElement('div');
  resultDisplay.id = 'extension-sum-result-display';
  
  // 스타일 지정 (페이지 내용과 겹치지 않도록 고정 위치)
  resultDisplay.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #333;
    color: white;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    z-index: 99999;
    font-size: 16px;
    font-family: sans-serif;
  `;
  
  resultDisplay.innerHTML = `
    <h4>✅ 확장 프로그램 계산 결과</h4>
    <p>a1 값: **${rawVal1}**</p>
    <p>a2 값: **${rawVal2}**</p>
    <hr>
    <p>총 합계: **${sum}**</p>
  `;

  // body의 맨 끝에 결과를 추가합니다.
  document.body.appendChild(resultDisplay);
}