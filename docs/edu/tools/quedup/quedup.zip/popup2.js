document.addEventListener('DOMContentLoaded', () => 
{  
  console.log("DOMContentLoaded");
  
    console.log("버튼 눌림");
    // threshold 확인
    const thres_element = document.getElementById('thres');
    const threshold = parseInt(thres_element.value);

    // 1. 현재 활성화된 탭 찾기
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => 
    {
      // 2. 해당 탭의 콘텐츠 스크립트로 메시지를 보내기
      // 메시지 타입은 'calculate_sum'으로 정의
      chrome.tabs.sendMessage(tabs[0].id, {action: "check_dup"}, (response) => 
      {
        if (chrome.runtime.lastError) 
        {
          // 에러 처리 (예: 해당 탭에 콘텐츠 스크립트가 로드되지 않았을 때)
          console.error("메시지 전송 실패:", chrome.runtime.lastError.message);
        } 
        else 
        {
          console.log("체크 완료 메시지 수신:", response);
          // 팝업 창 닫기
          window.close();
        }
      });
    });  
});