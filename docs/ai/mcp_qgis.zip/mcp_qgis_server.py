# server.py
from mcp.server.fastmcp import FastMCP
from qgis_client import QgisMCPClient

# MCP 서버 생성
app = FastMCP("QGIS MCP Server")


# 도구 정의: vector 레이어 추가
@app.tool()
def add_vector_layer(layer_name: str, layer_path: str) -> str:
    client = QgisMCPClient(host='localhost', port=9876)
    if not client.connect():
        print("Error: QGIS 플러그인에 연결할 수 없습니다.")
        return "Error: QGIS 플러그인에 연결할 수 없습니다."
    client.add_vector_layer(layer_path, layer_name)
    return f"{layer_name} 벡터 레이어를 추가했습니다."


# 도구 정의: 프로젝트 저장
@app.tool()
def save_project(path=None):
    client = QgisMCPClient(host='localhost', port=9876)
    if not client.connect():
        print("No se pudo conectar al servidor QGIS MCP")
        return "Error: QGIS 플러그인에 연결할 수 없습니다."
    client.save_project(path)
    return f"{path} 에 프로젝트를 저장했습니다."


# 도구 정의: render map
@app.tool()
def render_map(path, width: int=800, height: int=600, **kwargs):
    client = QgisMCPClient(host='localhost', port=9876)
    if not client.connect():
        print("No se pudo conectar al servidor QGIS MCP")
        return "Error: QGIS 플러그인에 연결할 수 없습니다."
    client.render_map(path, width, height)
    return f"{path} 에 맵을 렌더링했습니다."



# 도구 정의: qgis 정보
@app.tool()
def get_qgis_info(**kwargs):
    client = QgisMCPClient(host='localhost', port=9876)
    if not client.connect():
        print("Error: QGIS 플러그인에 연결할 수 없습니다.")
        return "Error: QGIS 플러그인에 연결할 수 없습니다."
    info = client.get_qgis_info()
    return f" QGIS 정보를 가져왔습니다: {info}"


# 도구 정의: 특정 위치에 점 추가
@app.tool()
def add_point(lat: float, lon:float, point_name: str) -> str:
    client = QgisMCPClient(host='localhost', port=9876)
    if not client.connect():
        print("Error: QGIS 플러그인에 연결할 수 없습니다.")
        return "Error: QGIS 플러그인에 연결할 수 없습니다."
    client.add_point(lat, lon, point_name)
    return f"{point_name} 포인터를 추가했습니다."




# 리소스 정의: 사용자 이름에 맞춘 인사말 제공
@app.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    return f"Hello, {name}!"


# 서버 실행
if __name__ == "__main__":
    print("Starting server...")
    
    app.run()


# uv run chainlit run app.py
# uv run E:\test\mcp\qgis_mcp\server.py
# client.add_vector_layer("e:\\temp\\data\\aa.shp", "test")
# qgis에 새 벡터 레이어를 추가해 줘. 벡터 파일 경로는 "e:\\temp\\data\\aa.shp"이고, 레이어 이름은 "test"야.
# qgis 프로젝트를 "e:\temp\qgis\test.qgz"에 저장해줘
# qgis 프로젝트의 내용을 "e:\\temp\\qgis\\test.png"에 렌더링 해줘
# qgis 프로젝트의 내용을 "e:\\temp\\qgis\\test.png"에 렌더링 해줘 가로는 2000, 세로는 1500이야